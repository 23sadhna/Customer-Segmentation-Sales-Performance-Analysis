/*
==========================================================================
PROJECT: E-commerce Customer Behavior Analysis
STEP 1: Database Setup and Data Exploration
==========================================================================
*/

-- 1. Created Database
CREATE DATABASE Customer_Segmentation_Project;
GO
USE Customer_Segmentation_Project;
GO

-- 2. Created Table Structure (As per the dataset columns)
CREATE TABLE orders (
    Order_ID VARCHAR(50),      
    Customer_ID VARCHAR(50),   
    Date DATE,
    Age INT,
    Gender VARCHAR(10),
    City VARCHAR(50),
    Product_Category VARCHAR(50),
    Unit_Price DECIMAL(10,2),
    Quantity INT,
    Discount_Amount DECIMAL(10,2),
    Total_Amount DECIMAL(10,2),
    Payment_Method VARCHAR(30),
    Device_Type VARCHAR(30),
    Session_Duration_Minutes INT,
    Pages_Viewed INT,
    Is_Returning_Customer VARCHAR(10), 
    Delivery_Time_Days INT,
    Customer_Rating INT
);

-- 3. Basic Data Exploration (Post-Import)
-- Checked first 10 rows
SELECT TOP 10 * FROM [dbo].[Ecommerce_customer_behavior_dataset (1)];

-- Counted total records to ensure full data load (Expecting 5000+)
SELECT COUNT(*) AS Total_Rows FROM [dbo].[Ecommerce_customer_behavior_dataset (1)];

-- Check for NULL values in key columns
SELECT 
    COUNT(*) - COUNT(Order_ID) AS Missing_Orders,
    COUNT(*) - COUNT(Customer_ID) AS Missing_Customers,
    COUNT(*) - COUNT(Total_Amount) AS Missing_Revenue
FROM [dbo].[Ecommerce_customer_behavior_dataset (1)];

-- 4. Unique Identifiers Check
SELECT COUNT(DISTINCT Customer_ID) AS Total_Unique_Customers FROM [dbo].[Ecommerce_customer_behavior_dataset (1)];

-- 5. Data Range Checked (To find Recency anchor point)
SELECT MIN(Date) AS Start_Date, MAX(Date) AS End_Date FROM [dbo].[Ecommerce_customer_behavior_dataset (1)];