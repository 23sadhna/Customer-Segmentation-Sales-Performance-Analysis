/*
================================================================================
PROJECT: E-commerce Business Analysis
PURPOSE: Digging into the data to find out what' driving 
         sales and where we might be losing customers.
================================================================================
*/

USE Customer_Segmentation_Project;
GO

--------------------------------------------------------------------------------
-- 1. Which product categories are bringing in the most cash?
-- This helps us decide which inventory to stock up on.
--------------------------------------------------------------------------------
SELECT 
    Product_Category, 
    SUM(Total_Amount) AS Total_Revenue,
    COUNT(Order_ID) AS Total_Orders,
    AVG(Customer_Rating) AS Avg_Rating
FROM [dbo].[Ecommerce_customer_behavior_dataset (1)]
GROUP BY Product_Category
ORDER BY Total_Revenue DESC;


-------------------------------------------------------------------------------
-- 2. Where are our customers located?
-- Useful for planning targeted marketing or logistics in specific cities.
--------------------------------------------------------------------------------
SELECT 
    City, 
    SUM(Total_Amount) AS Total_Revenue,
    COUNT(DISTINCT Customer_ID) AS Unique_Customers
FROM [dbo].[Ecommerce_customer_behavior_dataset (1)]
GROUP BY City
ORDER BY Total_Revenue DESC;


-------------------------------------------------------------------------------
-- 3. Monthly Sales Trend: Are we growing?
-- I used YEAR and MONTH here to see the revenue timeline clearly.
-------------------------------------------------------------------------------
SELECT 
    YEAR(Date) AS Sales_Year,
    MONTH(Date) AS Sales_Month,
    SUM(Total_Amount) AS Monthly_Revenue,
    COUNT(Order_ID) AS Total_Orders
FROM [dbo].[Ecommerce_customer_behavior_dataset (1)]
GROUP BY YEAR(Date), MONTH(Date)
ORDER BY Sales_Year, Sales_Month;


-- -----------------------------------------------------------------------------
-- 4. Tech & Payment Habits
-- Do mobile users spend more than desktop users? Let's find out.
--------------------------------------------------------------------------------
SELECT 
    Device_Type, 
    AVG(Total_Amount) AS Avg_Spend_Per_Order, 
    SUM(Total_Amount) AS Total_Revenue,
    COUNT(Order_ID) AS Total_Orders
FROM [dbo].[Ecommerce_customer_behavior_dataset (1)]
GROUP BY Device_Type
ORDER BY Total_Revenue DESC;

-- What is the preferred way to pay?
SELECT 
    Payment_Method, 
    AVG(Total_Amount) AS Average_Order_Value,
    COUNT(Order_ID) AS Usage_Count
FROM [dbo].[Ecommerce_customer_behavior_dataset (1)]
GROUP BY Payment_Method
ORDER BY Average_Order_Value DESC;

--------------------------------------------------------------------------------
--5.Does "Window Shopping" lead to actual buying?
-- Checking if customers who view more pages actually spend more.
--------------------------------------------------------------------------------
SELECT 
    CASE 
        WHEN Pages_Viewed <= 5 THEN 'Low Engagement (0-5 Pages)'
        WHEN Pages_Viewed <= 10 THEN 'Medium Engagement (6-10 Pages)'
        ELSE 'High Engagement (10+ Pages)'
    END AS Engagement_Level,
    AVG(Total_Amount) AS Avg_Spend,
    COUNT(*) AS Total_Orders
FROM [dbo].[Ecommerce_customer_behavior_dataset (1)]
GROUP BY 
    CASE 
        WHEN Pages_Viewed <= 5 THEN 'Low Engagement (0-5 Pages)'
        WHEN Pages_Viewed <= 10 THEN 'Medium Engagement (6-10 Pages)'
        ELSE 'High Engagement (10+ Pages)'
    END
ORDER BY Avg_Spend DESC;

--------------------------------------------------------------------------------
--6. The "Satisfaction" Factor: Delivery Speed vs Ratings
-- Analyzed the impact of delivery speed on customer ratings.
--------------------------------------------------------------------------------
SELECT 
    CASE 
        WHEN Delivery_Time_Days <= 3 THEN 'Fast Delivery (1-3 Days)'
        WHEN Delivery_Time_Days <= 6 THEN 'Average Delivery (4-6 Days)'
        ELSE 'Slow Delivery (7+ Days)'
    END AS Delivery_Speed,
    AVG(Customer_Rating) AS Avg_Rating,
    COUNT(*) AS Total_Orders
FROM [dbo].[Ecommerce_customer_behavior_dataset (1)]
GROUP BY 
    CASE 
        WHEN Delivery_Time_Days <= 3 THEN 'Fast Delivery (1-3 Days)'
        WHEN Delivery_Time_Days <= 6 THEN 'Average Delivery (4-6 Days)'
        ELSE 'Slow Delivery (7+ Days)'
    END;


-- -----------------------------------------------------------------------------
--7.Observed:Low Ratings & Slow Deliveries
-- A quick list of specific orders that need attention (Ratings of 1 or 2).
-------------------------------------------------------------------------------
SELECT 
    Customer_ID, 
    Product_Category, 
    Delivery_Time_Days, 
    Customer_Rating,
    Total_Amount
FROM [dbo].[Ecommerce_customer_behavior_dataset (1)]
WHERE Customer_Rating <= 2
ORDER BY Delivery_Time_Days DESC;