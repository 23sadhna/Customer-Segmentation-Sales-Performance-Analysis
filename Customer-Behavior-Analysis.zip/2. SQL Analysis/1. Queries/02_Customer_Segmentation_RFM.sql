/*
================================================================================
PROJECT: E-commerce Customer Behavior Analysis
MODULE 02: CUSTOMER SEGMENTATION USING RFM MODEL
Description: This script calculates Recency, Frequency, and Monetary values, 
             assigns scores, and segments customers into actionable groups.
================================================================================
*/

USE Customer_Segmentation_Project;


-- -----------------------------------------------------------------------------
-- STEP 2.1: CALCULATING RFM METRICS (BASE DATA)
-- Goal: Get the raw R, F, M values for each unique customer.
-- -----------------------------------------------------------------------------
SELECT 
    Customer_ID,
    DATEDIFF(DAY, MAX(Date), '2024-04-01') AS Recency, 
    COUNT(Order_ID) AS Frequency,
    SUM(Total_Amount) AS Monetary
FROM [dbo].[Ecommerce_customer_behavior_dataset (1)]
GROUP BY Customer_ID;


-- -----------------------------------------------------------------------------
-- STEP 2.2: ASSIGNING RFM SCORES (RANKING CUSTOMERS)
-- Goal: Use NTILE to rank customers from 1-5 based on their behavior.
-- -----------------------------------------------------------------------------
WITH RFM_Base AS (
    SELECT 
        Customer_ID,
        DATEDIFF(DAY, MAX(Date), '2024-04-01') AS Recency, 
        COUNT(Order_ID) AS Frequency,
        SUM(Total_Amount) AS Monetary
    FROM [dbo].[Ecommerce_customer_behavior_dataset (1)]
    GROUP BY Customer_ID
)
SELECT *,
    NTILE(5) OVER (ORDER BY Recency DESC) AS R_Score, -- Lower recency days = Higher Score (5)
    NTILE(5) OVER (ORDER BY Frequency ASC) AS F_Score, -- Higher frequency = Higher Score (5)
    NTILE(5) OVER (ORDER BY Monetary ASC) AS M_Score   -- Higher spending = Higher Score (5)
FROM RFM_Base;


-- -----------------------------------------------------------------------------
-- STEP 2.3: FINAL CUSTOMER SEGMENTATION (RFM MODEL)
-- Goal: Apply business logic to create named segments.
-- -----------------------------------------------------------------------------
WITH RFM_Scores AS (
    SELECT 
        Customer_ID,
        DATEDIFF(DAY, MAX(Date), '2024-04-01') AS Recency, 
        COUNT(Order_ID) AS Frequency,
        SUM(Total_Amount) AS Monetary,
        NTILE(5) OVER (ORDER BY DATEDIFF(DAY, MAX(Date), '2024-04-01') DESC) AS R,
        NTILE(5) OVER (ORDER BY COUNT(Order_ID) ASC) AS F,
        NTILE(5) OVER (ORDER BY SUM(Total_Amount) ASC) AS M
    FROM [dbo].[Ecommerce_customer_behavior_dataset (1)]
    GROUP BY Customer_ID
)
SELECT *,
    CASE 
        WHEN R >= 4 AND F >= 4 AND M >= 4 THEN 'Champions'
        WHEN R >= 3 AND F >= 3 THEN 'Loyal Customers'
        WHEN R >= 4 AND F <= 2 THEN 'New Customers'
        WHEN R <= 2 AND F >= 4 THEN 'At Risk'
        WHEN R <= 1 THEN 'Lost Customers'
        ELSE 'Potential Loyalist'
    END AS Customer_Segment
FROM RFM_Scores;


-- -----------------------------------------------------------------------------
-- STEP 2.4: CREATING A PERMANENT VIEW FOR REPORTING
-- Goal: Save the logic as a View to easily use it in Dashboards/Excel.
-- -----------------------------------------------------------------------------
-- Note: Check if view exists and drop it before creating if necessary
IF OBJECT_ID('Customer_Segmentation_Results', 'V') IS NOT NULL
    DROP VIEW Customer_Segmentation_Results;
GO

CREATE VIEW Customer_Segmentation_Results AS
WITH RFM_Scores AS (
    SELECT 
        Customer_ID,
        DATEDIFF(DAY, MAX(Date), '2024-04-01') AS Recency, 
        COUNT(Order_ID) AS Frequency,
        SUM(Total_Amount) AS Monetary,
        NTILE(5) OVER (ORDER BY DATEDIFF(DAY, MAX(Date), '2024-04-01') DESC) AS R,
        NTILE(5) OVER (ORDER BY COUNT(Order_ID) ASC) AS F,
        NTILE(5) OVER (ORDER BY SUM(Total_Amount) ASC) AS M
    FROM [dbo].[Ecommerce_customer_behavior_dataset (1)]
    GROUP BY Customer_ID
)
SELECT *,
    CASE 
        WHEN R >= 4 AND F >= 4 AND M >= 4 THEN 'Champions'
        WHEN R >= 3 AND F >= 3 THEN 'Loyal Customers'
        WHEN R >= 4 AND F <= 2 THEN 'New Customers'
        WHEN R <= 2 AND F >= 4 THEN 'At Risk'
        WHEN R <= 1 THEN 'Lost Customers'
        ELSE 'Potential Loyalist'
    END AS Customer_Segment
FROM RFM_Scores;
GO


-- -----------------------------------------------------------------------------
-- STEP 2.5: SEGMENT DISTRIBUTION ANALYSIS
-- Goal: Quick summary of the customer base for visual charts.
-- -----------------------------------------------------------------------------
SELECT 
    Customer_Segment, 
    COUNT(*) AS Total_Customers
FROM Customer_Segmentation_Results
GROUP BY Customer_Segment
ORDER BY Total_Customers DESC;